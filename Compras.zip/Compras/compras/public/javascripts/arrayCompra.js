const compraFinalizada=[]

module.exports ={compraFinalizada}