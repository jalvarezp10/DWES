const productos=[
    {
        "sku": "abc123",
        "nombre": "Gel de baño",
        "precio": 5.99,
        "cantidad": 0

    },
    {
        "sku": "abc564",
        "nombre": "Paquete de patatas",
        "precio": 2.50,
        "cantidad": 0

    },
    {
        "sku": "dcj134",
        "nombre": "Toallitas",
        "precio": 3.76,
        "cantidad": 0

    },
    {
        "sku": "723bsa",
        "nombre": "Cuchillo",
        "precio": 15.99,
        "cantidad": 0

    },
    {
        "sku": "qwe343",
        "nombre": "Papel higiénico",
        "precio": 1.99,
        "cantidad": 0

    },
    {
        "sku": "3423jdk",
        "nombre": "Mostaza",
        "precio": 2.90,
        "cantidad": 0

    },
    {
        "sku": "343jasj",
        "nombre": "Champú",
        "precio": 6.99,
        "cantidad": 0

    },
    {
        "sku": "8892jks",
        "nombre": "chicles",
        "precio": 1.99,
        "cantidad": 0

    },
    {
        "sku": "234jskkkas",
        "nombre": "Ensalada cesar",
        "precio": 4.99,
        "cantidad": 0

    },
    {
        "sku": "871kws2",
        "nombre": "Pechuga de pollo",
        "precio": 6.99,
        "cantidad": 0

    }
]




module.exports ={productos}