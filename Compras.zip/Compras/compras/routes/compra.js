var express = require('express');
var router = express.Router();
const {arrayCompra}=require('/home/julianalvarez/Escritorio/Compras/compras/public/javascripts/arrayCompra.js');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.json(arrayCompra);
});

router.get('/:sku', function(req, res,) {
    const{sku}=req.params
    const producto=arrayCompra.find((producto) => producto.sku===sku);
    if(!producto){
      res.status(404).send('El item no se ha encontrado');
    }else{
      res.status(200).json(producto);
    }
  }
  )
  
 
  
  
  
    router.put('/:sku',function(req, res) {
      var update_producto=req.body;
      const {sku}=req.params;
      const productoIndex=arrayCompra.findIndex((producto) => producto.sku===sku);
      if(productoIndex===-1){
        res.status(404).send('el item no se ha encontrado');
    
      }else{
        arrayCompra[productoIndex]=update_producto;
        res.status(200).send('El post con id '+sku+' ha sido actualizado correctamente');
      }
      
      
    })
    
    router.delete('/:sku',function(req, res) {
      
      const {sku}=req.params;
      const productoIndex=arrayCompra.findIndex((producto) => producto.sku===sku);
      if(productoIndex===-1){
        res.status(404).send('el item no se ha encontrado');
    
      }else{
        arrayCompra.splice(productoIndex,1);
        res.status(200).send('El user con id '+sku+' ha sido eliminado correctamente');
      }
      
      
    })
  

module.exports = router;
