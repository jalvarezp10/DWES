var express = require('express');
var router = express.Router();
var mongoose=require('mongoose');
var db= mongoose.connection;

var User=require('../models/user');
var Post=require('../models/post');


/* GET users listing. */
router.get('/', function(req, res, next) {
  Post.find().sort('-creationdate').exec(function(err,posts) {
    if (err) res.status(500).send(err);
      else res.status(200).json(posts);

})});


router.get('/search', (req, res) => {
  const { usuario, fecha, titulo } = req.params;

  // Construye el objeto de filtro basado en los parámetros proporcionados
  const filter = {};
  if (usuario) {
    filter.userId = usuario;
  }
  if (fecha) {
    filter.date = fecha;
  }
  if (titulo) {
    filter.title = titulo;
  }

  // Realiza la consulta a la base de datos para obtener los posts según los parámetros proporcionados
  Post.find(filter)
    .populate('userId', 'username') // Para obtener solo el nombre de usuario en lugar de todos los datos del usuario
    .populate('commentId', 'title') // Para obtener solo el título del comentario en lugar de todos los datos del comentario
    .exec((err, posts) => {
      if (err) {
        console.error('Error al buscar los posts', err);
        return res.status(500).json({ error: 'Error al buscar los posts' });
      }
      res.json(posts);
    });
});

/*Post*/

router.post('/', function(req, res, next) {
  User.findById(req.body.user, function(err, userinfo) {
  if (err) res.status(500).send(err);
  else {
  // crear el post
  var postNuevo = new Post({
    user: req.body.user,
    title: req.body.title,
    description: req.body.description
  });
  // añadir postInstance al array de posts del usuario
  userinfo.posts.push(postNuevo)
  
  userinfo.save(function(err) {
  if (err) res.status(500).send(err);
  else {
    postNuevo.save(function(err) {
      if (err) res.status(500).send(err);
      res.sendStatus(200);
    });
  }
  });
  }
  });
  });


/*Get por id */
router.get('/:id', function(req, res, next) {
  Post.findById(req.params.id, function(err, userinfo) {
  if (err) res.status(500).send(err);
  else res.status(200).json(userinfo);
  });
  });


router.get('/all/:id', function(req, res, next) {
   Post.find({ 'user': req.params.id
   }).exec(function(err, posts)
   {
   if (err) res.status(500).send(err);
   else res.status(200).json(posts);
   });
 });


/*UPDATE por id*/
router.put('/:id',function(req,res,next){
  Post.findByIdAndUpdate(req.params.id,req.body,function(err,postinfo){
    if (err) res.status(500).send(err);
        else res.sendStatus(200);
  })
})

/*DELETE*/
router.delete('/:id', function(req, res, next) {
  Post.findByIdAndDelete(req.params.id, function(err, userinfo) {
  if (err) res.status(500).send(err);
  else res.sendStatus(200);
  });
  });

module.exports = router;
