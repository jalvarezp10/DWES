var express = require('express');
var router = express.Router();
var mongoose=require('mongoose');
var db= mongoose.connection;

var User=require('../models/user');


/* GET users listing. */
router.get('/', function(req, res, next) {
  User.find().sort('-creationdate').exec(function(err,users) {
    if (err) res.status(500).send(err);
      else res.status(200).json(users);

})});



/*Post*/

router.post('/', function(req, res, next) {
  User.create(req.body, function(err, userinfo) {
  if (err) res.status(500).send(err);
  else res.sendStatus(200);
  });
  });






// POSt si el usuario existe
router.post('/signin', function(req, res, next) {
  User.findOne({ username: req.body.username }, function(err, user) {
  if (err) res.status(500).send('¡Error comprobando el usuario!');
 
  if (user != null) {
  user.comparePassword(req.body.password, function(err,
  isMatch) {
  if (err) return next(err);
  
  if (isMatch)
  res.status(200).send({ message: 'ok', role:
  user.role, id: user._id });
  else
  res.status(200).send({ message: 'la password no coincide' });
  });
  } else res.status(401).send({ message: 'usuario no registrado'
  });
  });
  });


/*Get por id */
router.get('/:id', function(req, res, next) {
  User.findById(req.params.id, function(err, userinfo) {
  if (err) res.status(500).send(err);
  else res.status(200).json(userinfo);
  });
  });



  /*Get por username querystring*/
router.get('/:username', function(req, res, next) {
  User.findOne(req.query.username  , function(err, userinfo) {
  if (err) res.status(500).send(err);
  else res.status(200).json(userinfo);
  });
  });
  /*Get por username querystring*/
  router.get('name/:username', function(req, res, next) {
    User.findOne(req.params.username  , function(err, userinfo) {
    if (err) res.status(500).send(err);
    else req.status(200).json(userinfo);
    });
    });


/*UPDATE por id*/
router.put('/:id',function(req,res,next){
  User.findByIdAndUpdate(req.params.id,req.body,function(err,postinfo){
    if (err) res.status(500).send(err);
        else res.sendStatus(200);
  })
})
/*UPDATE por username*/
router.put('name/:username',function(req,res,next){
  const username = req.params.username;
  User.findOneAndUpdate({username:username},function(err,postinfo){
    if (err) res.status(500).send(err);
        else res.sendStatus(200);
  })
})

/*UPDATE role a subscriber*/
router.put('/all/subs', function(req, res, next) {
  const { role } = req.params;

  // Actualizar el rol de los usuarios según el parámetro role
  User.updateMany({}, { role: 'subscriber' }, function(err, postinfo) {
    if (err) {
      res.status(500).send(err);
    } else {
      res.sendStatus(200);
    }
  });
});



// DELETE de un usuario existente identificado por su Id
router.delete('/:id', function(req, res, next) {
  User.findByIdAndDelete(req.params.id, function(err, userinfo) {
  if (err) res.status(500).send(err);
  else res.sendStatus(200);
  });
  });

module.exports = router;


// DELETE de un usuario existente identificado por su Username
router.delete('/name/:username', function(req, res, next) {
  const username = req.params.username;

  User.findOneAndDelete({ username:username }, function(err, userinfo) {
    if (err) {
      res.status(500).send(err);
    } else {
      res.sendStatus(200);
    }
  });
});




module.exports = router;
