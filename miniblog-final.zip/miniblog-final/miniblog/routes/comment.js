var express = require('express');
var router = express.Router();
var mongoose=require('mongoose');
var db= mongoose.connection;

var Comment = require('../models/comment')

/* GET users listing. */
router.get('/', function(req, res, next) {
    Comment.find().sort('-creationdate').exec(function(err,comments) {
      if (err) res.status(500).send(err);
        else res.status(200).json(comments);
  
  })});


/*Post*/

router.post('/', function(req, res, next) {
  Post.findById(req.body.post, function(err, postinfo) {
  if (err) res.status(500).send(err);
  else {
  // crear el comment
  var commentNuevo = new Comment({
  user: req.body.user,
  post:req.body.post,
  text: req.body.text,
  
  });
  
  postinfo.comments.push(commentNuevo);
  
  postinfo.save(function(err) {
  if (err) res.status(500).send(err);
  else {
  commentNuevo.save(function(err) {
  if (err) res.status(500).send(err);
  res.sendStatus(200);
  });
  }
  });
  }
  });
  });

    /*UPDATE por id*/
router.put('/:id',function(req,res,next){
    Comment.findByIdAndUpdate(req.params.id,req.body,function(err,commentinfo){
      if (err) res.status(500).send(err);
          else res.sendStatus(200);
    })
  })



  router.get('/all/:id', function(req, res, next) {
    Comment.find({ 'post': req.params.id
    }).sort('-creationdate').exec(function(err, comments)
    {
    if (err) res.status(500).send(err);
    else res.status(200).json(comments);
    });
  });

  /*DELETE*/
router.delete('/:id', function(req, res, next) {
    Comment.findByIdAndDelete(req.params.id, function(err, commentinfo) {
    if (err) res.status(500).send(err);
    else res.sendStatus(200);
    });
    });
  
  module.exports = router;
  
