var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var User=require('../models/user.js');
var Comment=require('../models/comment.js');
var PostSchema=new Schema({
    user:{
        type:Schema.ObjectId,
        ref:'User'
    },
    title:String,
    description:String,
    publicationdate:{type:Date,default:Date.now},
    comments:[{
        type: Schema.ObjectId,
        ref: 'Comment',
        default: null
    }]
    


});

module.exports =mongoose.model('Post',PostSchema);