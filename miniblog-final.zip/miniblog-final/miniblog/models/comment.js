var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var User=require('../models/user.js');
var Post=require('../models/post.js');

var CommentSchema=new Schema({
    user:{
        type:Schema.ObjectId,
        ref:'User'
    },
    post:{
        type:Schema.ObjectId,
        ref:'Post'
    },
    text:String,
    creationdate:{type:Date,default:Date.now}

});

module.exports = mongoose.model('Comment ', CommentSchema);